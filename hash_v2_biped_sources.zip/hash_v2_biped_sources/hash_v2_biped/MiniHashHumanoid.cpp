#include "MiniHashHumanoid.h"

#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>
Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);

#define min_pulse_width 100
#define max_pulse_width 550
#define frequency 50

/* Initializing servo drive and OLED display */
void MiniHashHumanoid::init_hash() {
  pwm.begin();
  pwm.setPWMFreq(frequency);

}

/* Servo angle setting */
void MiniHashHumanoid::set_servo(int servo, int servo_pwm) {
  pwm.setPWM(servo, 0, servo_pwm);
}

/* Initial position */
void MiniHashHumanoid::initial_position() {
  int pwm_array[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325}; /* RH1,RH2,RL1,RL2,LH1,LH2,LL1,LL2,HEAD,DMY1,DMY2,DMY3,DMY4,DMY5,DMY6 */
  for (int i = 0; i < 16; i++) {
    servo_position[i] = pwm_array[i];
  }
  move_servo(2000, pwm_array);
}
/* Moving each servo at given time interval */
void MiniHashHumanoid::move_servo(int time, int  servo_target[]) {

  if (time > 10) {
    for (int i = 0; i < 16; i++) {
      increment[i] = ((servo_target[i]) - servo_position[i]) / (time / 10.0);
    }
    final_time =  millis() + time;

    for (int iteration = 1; millis() < final_time; iteration++) {
      partial_time = millis() + 10;

      for (int i = 0; i < 16; i++) {
        set_servo(i, (int)(servo_position[i] + (iteration * increment[i])));
      }
      while (millis() < partial_time);
    }
  }
  else {
    for (int i = 0; i < 16; i++) {
      set_servo(i, (int)servo_target[i]);
    }
  }
  for (int i = 0; i < 16; i++) {
    servo_position[i] = servo_target[i];
  }
}


/******************************************************************************************************/
void MiniHashHumanoid::max_sit(int count) {

  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);
  for (int i = 1; i <= count; i++) {
    int pwm_array1[16] = {325, 250, 225, 175, 325, 325, 325, 400, 425, 475, 325, 325, 325, 325, 325, 325};
    move_servo(2000, pwm_array1);
    delay(2000);
    int pwm_array3[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(2000, pwm_array3);
  }
}

/******************************************************************************************************/
void MiniHashHumanoid::move_forward(int steps) {

  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  int pwm_array2[16] = {375, 475, 475, 175, 375, 325, 375, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  int pwm_array3[16] = {375, 475, 400, 250, 375, 325, 375, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  int pwm_array4[16] = {325, 475, 400, 250, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);
  move_servo(1000, pwm_array2);
  move_servo(1000, pwm_array3);
  move_servo(1000, pwm_array4);
  for (int i = 1; i <= steps; i++) {
    int pwm_array5[16] = {275, 475, 475, 175, 325, 325, 275, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    int pwm_array6[16] = {275, 475, 475, 175, 325, 325, 275, 175, 250, 400, 275, 325, 325, 325, 325, 325};
    int pwm_array7[16] = {325, 475, 475, 175, 325, 325, 325, 175, 250, 400, 325, 325, 325, 325, 325, 325};
    int pwm_array8[16] = {375, 475, 475, 175, 375, 325, 375, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array9[16] = {375, 475, 400, 250, 375, 325, 375, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array10[16] = {325, 475, 400, 250, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array5);
    move_servo(1000, pwm_array6);
    move_servo(1000, pwm_array7);
    move_servo(1000, pwm_array8);
    move_servo(1000, pwm_array9);
    move_servo(1000, pwm_array10);
  }
  int pwm_array11[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array11);
}

/******************************************************************************************************************/
void MiniHashHumanoid::turn_right(int steps) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= steps; i++) {
    int pwm_array2[16] = {275, 475, 475, 175, 325, 325, 275, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {275, 475, 450, 175, 325, 300, 275, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    int pwm_array4[16] = {325, 475, 450, 175, 325, 300, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array5[16] = {375, 475, 475, 175, 375, 300, 375, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array6[16] = {375, 475, 475, 175, 375, 325, 375, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array7[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(1000, pwm_array3);
    move_servo(1000, pwm_array4);
    move_servo(1000, pwm_array5);
    move_servo(1000, pwm_array6);
    move_servo(1000, pwm_array7);
  }
  int pwm_array8[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array8);
}

/******************************************************************************************************************/
void MiniHashHumanoid::turn_left(int steps) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= steps; i++) {
    int pwm_array2[16] = {375, 475, 475, 175, 375, 325, 375, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {375, 475, 475, 175, 375, 325, 375, 175, 200, 475, 325, 350, 325, 325, 325, 325};
    int pwm_array4[16] = {325, 475, 475, 175, 325, 325, 325, 175, 200, 475, 325, 350, 325, 325, 325, 325};
    int pwm_array5[16] = {275, 475, 475, 175, 325, 325, 275, 175, 175, 475, 275, 350, 325, 325, 325, 325};
    int pwm_array6[16] = {275, 475, 475, 175, 325, 325, 275, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    int pwm_array7[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(1000, pwm_array3);
    move_servo(1000, pwm_array4);
    move_servo(1000, pwm_array5);
    move_servo(1000, pwm_array6);
    move_servo(1000, pwm_array7);
  }
  int pwm_array8[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array8);
}

/******************************************************************************************************/
void MiniHashHumanoid::move_right(int steps) {

  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= steps; i++) {
    int pwm_array2[16] = {375, 475, 475, 175, 380, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {275, 475, 475, 175, 275, 325, 275, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    int pwm_array4[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(1000, pwm_array3);
    move_servo(1000, pwm_array4);

  }
  int pwm_array5[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array5);
}

/******************************************************************************************************/
void MiniHashHumanoid::move_left(int steps) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= steps; i++) {
    int pwm_array2[16] = {325, 475, 475, 175, 325, 325, 275, 175, 175, 475, 270, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {375, 475, 475, 175, 375, 325, 375, 175, 175, 475, 375, 325, 325, 325, 325, 325};
    int pwm_array4[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(1000, pwm_array3);
    move_servo(1000, pwm_array4);

  }
  int pwm_array5[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array5);
}

/******************************************************************************************************/
void MiniHashHumanoid::ball_kick_right(int count) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= count; i++) {
    int pwm_array2[16] = {380, 475, 475, 175, 375, 325, 380, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {380, 425, 450, 125, 375, 325, 380, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array4[16] = {380, 475, 450, 250, 375, 325, 380, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array5[16] = {380, 475, 475, 175, 375, 325, 380, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(500, pwm_array3);
    move_servo(500, pwm_array4);
    move_servo(1000, pwm_array5);
  }
  int pwm_array6[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array6);
}

/******************************************************************************************************/
void MiniHashHumanoid::ball_kick_left(int count) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= count; i++) {
    int pwm_array2[16] = {270, 475, 475, 175, 325, 325, 270, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {270, 475, 475, 175, 325, 325, 270, 225, 200, 525, 275, 325, 325, 325, 325, 325};
    int pwm_array4[16] = {270, 475, 475, 175, 325, 325, 270, 175, 200, 400, 275, 325, 325, 325, 325, 325};
    int pwm_array5[16] = {270, 475, 475, 175, 325, 325, 270, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(500, pwm_array3);
    move_servo(500, pwm_array4);
    move_servo(1000, pwm_array5);
  }
  int pwm_array6[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array6);
}

/******************************************************************************************************/
void MiniHashHumanoid::right_leg_up(int count) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= count; i++) {
    int pwm_array2[16] = {380, 475, 475, 175, 375, 325, 380, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {380, 450, 350, 300, 375, 325, 380, 175, 175, 500, 325, 325, 325, 325, 325, 325};
    int pwm_array4[16] = {380, 475, 475, 175, 375, 325, 380, 175, 175, 475, 325, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(1000, pwm_array3);
    move_servo(1000, pwm_array4);
  }
  int pwm_array5[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array5);
}

/******************************************************************************************************/
void MiniHashHumanoid::left_leg_up(int count) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= count; i++) {
    int pwm_array2[16] = {270, 475, 475, 175, 325, 325, 270, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    int pwm_array3[16] = {270, 475, 475, 150, 325, 325, 270, 200, 300, 350, 275, 325, 325, 325, 325, 325};
    int pwm_array4[16] = {270, 475, 475, 175, 325, 325, 270, 175, 175, 475, 275, 325, 325, 325, 325, 325};
    move_servo(1000, pwm_array2);
    move_servo(1000, pwm_array3);
    move_servo(1000, pwm_array4);
  }
  int pwm_array5[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array5);
}

/******************************************************************************************************/
void MiniHashHumanoid::right_leg_bend(int count) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= count; i++) {
    int pwm_array2[16] = {325, 475, 325, 325, 325, 325, 325, 325, 325, 475, 325, 325, 325, 325, 325, 325};
    move_servo(2000, pwm_array2);
  }
  int pwm_array3[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(2000, pwm_array3);
}

/******************************************************************************************************/
void MiniHashHumanoid::left_leg_bend(int count) {
  int pwm_array1[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(1000, pwm_array1);

  for (int i = 1; i <= count; i++) {
    int pwm_array2[16] = {325, 325, 325, 175, 325, 325, 325, 175, 325, 325, 325, 325, 325, 325, 325, 325};
    move_servo(2000, pwm_array2);
  }
  int pwm_array3[16] = {325, 475, 475, 175, 325, 325, 325, 175, 175, 475, 325, 325, 325, 325, 325, 325};
  move_servo(2000, pwm_array3);
}

/******************************************************************************************************/
