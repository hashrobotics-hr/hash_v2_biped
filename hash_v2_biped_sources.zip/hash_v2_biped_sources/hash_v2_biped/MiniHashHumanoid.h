
class MiniHashHumanoid
{
  public:

    /* Variable declaration */
    int servo_position[16];
    float increment[16];
    unsigned long final_time;
    unsigned long partial_time;

    /* Method declaration */
    void init_hash();
    void set_servo(int servo, int servo_pwm);
    void initial_position();
    void move_servo(int time, int  servo_target[]);
    void test(int count = 1);

    void max_sit(int steps = 1);
    void move_forward(int steps = 1);
    void turn_right(int steps = 1);
    void turn_left(int steps = 1);
    void move_right(int steps = 1);
    void move_left(int steps = 1);

    void ball_kick_right(int count = 1);
    void ball_kick_left(int count = 1);
    void right_leg_up(int count = 1);
    void left_leg_up(int count = 1);
    void right_leg_bend(int count = 1);
    void left_leg_bend(int count = 1);


};
